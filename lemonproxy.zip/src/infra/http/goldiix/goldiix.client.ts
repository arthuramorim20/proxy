import axios, { AxiosInstance } from "axios";
import { env } from "../../../config/env";

let accessToken: string | null = null;
let tokenExpiresAt: number | null = null;

function getBasicAuthHeader() {
  const credentials = `${env.goldiix.publicKey}:${env.goldiix.secretKey}`;
  return `Basic ${Buffer.from(credentials).toString("base64")}`;
}

async function authenticate(client: AxiosInstance) {
  if (accessToken && tokenExpiresAt && Date.now() < tokenExpiresAt - 60_000) {
    return accessToken;
  }

  const { data } = await client.post(
    "/api/v2/auth/generate_token",
    {},
    {
      headers: {
        Authorization: getBasicAuthHeader(),
        "Content-Type": "application/json",
        Accept: "application/json",
      },
      timeout: 10000,
    },
  );

  accessToken = data.access_token;
  tokenExpiresAt = Date.now() + data.expires_in * 1000;

  return accessToken;
}

export function createGoldiixClient(): AxiosInstance {
  const client = axios.create({
    baseURL: env.goldiix.baseUrl,
    timeout: 15000,
  });

  // 🔐 inject bearer token
  client.interceptors.request.use(async (config) => {
    const token = await authenticate(client);
    config.headers.Authorization = `Bearer ${token}`;
    return config;
  });

  // 🔁 retry automático em 401
  client.interceptors.response.use(
    (response) => response,
    async (error) => {
      if (error.response?.status === 401) {
        accessToken = null;
        tokenExpiresAt = null;
        return client.request(error.config);
      }
      return Promise.reject(error);
    },
  );

  return client;
}

export const goldiixClient = createGoldiixClient();
